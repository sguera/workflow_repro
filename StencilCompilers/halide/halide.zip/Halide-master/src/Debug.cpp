#include "Debug.h"

namespace Halide {
namespace Internal {

int debug::debug_level = 0;
bool debug::initialized = false;

}
}
