#include "InjectSyncthreads.h"

namespace Halide {
namespace Internal {

Stmt inject_syncthreads(Stmt s) {
    return s;
}

}
}
