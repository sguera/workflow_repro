#define SYS_CLOCK_GETTIME 263
#include "linux_clock.cpp"
