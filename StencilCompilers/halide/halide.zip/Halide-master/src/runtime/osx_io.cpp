#define stderr __stderrp
#include "posix_io.cpp"
