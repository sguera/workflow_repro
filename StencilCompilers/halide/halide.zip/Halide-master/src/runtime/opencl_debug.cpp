#define DEBUG
#include "opencl.cpp"
