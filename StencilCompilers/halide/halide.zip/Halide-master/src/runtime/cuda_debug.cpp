#define DEBUG
#include "cuda.cpp"
