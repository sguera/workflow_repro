// This file should be auto-generated in the future
#include <Halide.h>

namespace my_library {

Halide::Func vignette(Halide::Func in, Halide::Expr center_x, Halide::Expr center_y, Halide::Expr radius);
Halide::Func flip(Halide::Func in, Halide::Expr total_width);

}
