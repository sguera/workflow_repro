#ifndef HALIDE_OPENGLSUPPORT_H
#define HALIDE_OPENGLSUPPORT_H

extern "C" int halide_opengl_create_context();

#endif
