
// This test demonstrates using tracing to give you something like a
// stack trace in case of a crash (due to a compiler bug, or a bug in
// external code). We use a posix signal handler, which is probably
// os-dependent, so I'm going to enable this test on linux only.

#if defined(__linux__) || defined(__APPLE__) || defined(__unix) || defined(__posix)

#include <Halide.h>
#include <stdio.h>
#include <signal.h>
#include <stack>
#include <string>

using namespace Halide;
using std::stack;
using std::string;

stack<string> stack_trace;


int my_trace(void *user_context, const halide_trace_event *e) {
    const string event_types[] = {"Load ",
                                  "Store ",
                                  "Begin realization ",
                                  "End realization ",
                                  "Produce ",
                                  "Update ",
                                  "Consume ",
                                  "End consume "};

    if (e->event == 3 || e->event > 4) {
        // These events signal the end of some previous event
        stack_trace.pop();
    }
    if (e->event == 2 || e->event == 4 || e->event == 5 || e->event == 6) {
        // These events signal the start of some new region
        stack_trace.push(event_types[e->event] + e->func);
    }

    return 0;
}

void signal_handler(int signum) {
    printf("Correctly triggered a segfault. Here is the stack trace:\n");
    while (!stack_trace.empty()) {
        printf("%s\n", stack_trace.top().c_str());
        stack_trace.pop();
    }

    printf("Success!\n");
    exit(0);
}


int main(int argc, char **argv) {

    signal(SIGSEGV, signal_handler);
    signal(SIGBUS, signal_handler);

    // Loads from this image will barf, because we've messed up the host pointer
    Image<int> input(100, 100);
    buffer_t *buf = input.raw_buffer();
    buf->host = (uint8_t *)17;

    Func f("f"), g("g"), h("h");
    Var x("x"), y("y");

    f(x, y) = x+y;
    f.compute_root().trace_realizations();

    g(x, y) = f(x, y) + 37;
    g.compute_root().trace_realizations();

    h(x, y) = g(x, y) + input(x, y);
    h.trace_realizations();

    h.set_custom_trace(&my_trace);
    h.realize(100, 100);

    printf("The code should not have reached this print statement.\n");
    return -1;
}

#else

#include <stdio.h>

int main(int argc, char **argv) {
    printf("Test skipped because we're not on a system with UNIX signal handling\n");
    return 0;
}

#endif
